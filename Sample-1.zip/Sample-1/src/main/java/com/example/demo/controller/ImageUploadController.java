package com.example.demo.controller;

import java.io.IOException;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.entity.User;

@Controller
public class ImageUploadController {
@PostMapping("/uploadImageToDB")
public String uploadImgaeToDB(@RequestParam("imageFile") MultipartFile imageFile, User model) throws IOException {
byte[] imageArr = imageFile.getBytes(); 

String imageAsString= Base64.encodeBase64String(imageArr);
 //code to store the @code{imageAsString} object 
// to database}

//DisplayImageFromDB.jsp
return "Display_Image";
} 
}