package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.Instructor;
import com.example.demo.entity.InstructorDetail;
import com.example.demo.repository.InstructorRepository;

@SpringBootApplication
public class Sample1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sample1Application.class, args);
	}
	@Autowired
    private InstructorRepository instructorRepository;

    public void run(String...args) throws Exception {

        Instructor instructor = new Instructor("Ramesh", "Fadatare", "ramesh@gmail.com");

        InstructorDetail instructorDetail = new InstructorDetail("Java Guides", "Cricket Playing");

        // associate the objects
        instructor.setInstructorDetail(instructorDetail);

        instructorRepository.save(instructor);
    }
}
