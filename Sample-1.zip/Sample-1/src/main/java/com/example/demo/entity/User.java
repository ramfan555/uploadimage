package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Lob;

public class User {
	        @Lob
	        @Column(name = "profile_image")
	        private byte[] profileImage;

	        public byte[] getProfileImage() {
	            return profileImage;
	        }

	        public void setProfileImage(byte[] profileImage) {
	            this.profileImage = profileImage;
	        }
	}