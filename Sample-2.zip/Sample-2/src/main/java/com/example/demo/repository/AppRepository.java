package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.MODEL.AppModel;

public interface AppRepository extends JpaRepository<AppModel, Long>{

}
